


show columns from users_userprofile;
show columns from projects_project;
show columns from projects_participation;
show columns from relationships_relationship;
show columns from courses_course;
show columns from courses_cohort;
show columns from courses_cohortsignup;
show columns from newcourses;
show columns from newcourseusers;



#---------------------------------------
show columns from users_userprofile;

select 
id,
#remove# username,
#remove# full_name,
#remove# password,
#remove# email,
#remove# bio,
#remove# image,
#remove# confirmation_code,
location,
featured,
#remove# newsletter,
#remove# discard_welcome,
created_on,
preflang,
deleted,
last_active
#remove# user_id
from users_userprofile
where deleted = 0;



#---------------------------------------
show columns from relationships_relationship;

SELECT
id,
source_id,
target_user_id,
target_project_id,
created_on,
deleted
from relationships_relationship;



#---------------------------------------
show columns from projects_project;

select
id
name,
short_name,
category,
language,
other,
other_description,
short_description,
long_description,
start_date,
end_date,
duration_hours,
duration_minutes,
school_id,
detailed_description_id,
image,
slug,
featured,
community_featured,
created_on,
test,
under_development,
not_listed,
archived,
clone_of_id,
imported_from,
deleted
from projects_project;

#---------------------------------------
show columns from projects_participation;


select
id,
user_id,
project_id,
organizing,
adopter,
joined_on,
left_on,
no_organizers_wall_updates,
no_organizers_content_updates,
no_participants_wall_updates,
no_participants_content_updates,
sign_up_id
from projects_participation;


#---------------------------------------
show columns from courses_course;

/* table not included in release
SELECT
id,
title,
short_title,
description,
language,
image_uri,
creation_date,
draft,
archived,
deleted,
creator_uri,
based_on_id
from courses_course;
*/

#---------------------------------------
show columns from courses_cohort;

SELECT
id,
course_id,
term,
start_date,
end_date,
signup
from courses_cohort;


#---------------------------------------
show columns from courses_cohortsignup;
/* table not included in release
SELECT
id,
cohort_id,
#remove# user_uri,
role,
signup_date,
leave_date
from courses_cohortsignup;
*/

#---------------------------------------
show columns from newcourses;

SELECT
courses_course_id,
title,
short_title,
description,
language,
image_uri,
creation_date,
draft,
archived,
deleted,
#remove# creator_uri,
#remove# creator,
based_on_id,
courses_cohort_id,
course_id,
term,
start_date,
end_date,
signup
from newcourses;


#---------------------------------------
show columns from newcourseusers;


SELECT
courses_cohortsignup_id,
cohort_id,
#remove# user_uri,
#remove# user,
role,
signup_date,
leave_date,
users_userprofile_id,
#remove# username,
#remove# full_name,
#remove# password,
#remove# email,
#remove# bio,
#remove# image,
#remove# confirmation_code,
location,
featured,
#remove# newsletter,
#remove# discard_welcome,
created_on,
preflang,
deleted,
last_active
#remove# user_id
from newcourseusers;
