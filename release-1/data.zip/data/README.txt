README FILE

P2PU Data Release 1
Participation Tables
4/4/2014

--------------------------------------------

This is a dataset containing the tables from the P2PU database that relate to users and classes.  

The data in this release is a snapshot of the P2PU database that was captured on Sept 17, 2013.

Included in the release are:
- Data Dictionary: definitions of tables and fields
- Data Model: visually representing the relationships between the data objects
- Data Files: CSV files for each table or view
- Data Creation SQL Script
- Readme File
- License File


